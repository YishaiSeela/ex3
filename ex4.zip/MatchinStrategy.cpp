#include "MatchinStrategyTest.h"
#include "MatchinStrategy.h"

MatchinStrategy::MatchinStrategy()
/**
* Ctor
*/
{
}


MatchinStrategy::~MatchinStrategy()
/**
* Dtor
*/
{
}


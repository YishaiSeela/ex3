/*
 * EventNotifier.cpp
 *
 *  Created on: Nov 30, 2016
 *      Author: adidush0212
 */

#include "EventNotifier.h"


    EventNotifier::EventNotifier()
    /**
    * Ctor
    */
    {

    }

    EventNotifier::~EventNotifier()
    /**
    * Dtor
    */
    {

    }


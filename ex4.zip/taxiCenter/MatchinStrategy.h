#ifndef MATCHINSTRATEGY
#define MATCHINSTRATEGY
#include "../Persons/Driver.h"
#include "../Persons/Passanger.h"

class MatchinStrategy
{
	//List Pass
public:

	MatchinStrategy();
	~MatchinStrategy();


};

#endif

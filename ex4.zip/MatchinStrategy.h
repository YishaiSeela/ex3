#ifndef MATCHINSTRATEGY
#define MATCHINSTRATEGY
#include "Driver.h"
#include "Passanger.h"

class MatchinStrategy
{
	//List Pass
public:

	MatchinStrategy();
	~MatchinStrategy();


};

#endif
